package com.thewarehouses.thewarehousespecials

import androidx.lifecycle.ViewModel
import getBranchName
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class MainViewModel : ViewModel() {
    private val _branchNames = MutableStateFlow<List<String>>(emptyList())
    val branchNames: StateFlow<List<String>> = _branchNames

    private val _selectedBranch = MutableStateFlow<String?>(null)
    val selectedBranch: StateFlow<String?> = _selectedBranch

    private val _products = MutableStateFlow<List<Map<String, Any>>>(emptyList())
    val products: StateFlow<List<Map<String, Any>>> = _products

    private val viewModelScope = CoroutineScope(Dispatchers.Main + Job())

    fun loadBranchNames() {
        viewModelScope.launch {
            val names = getBranchName() // Fetch branch names
            _branchNames.value = names
        }
    }

    fun selectBranch(branchId: String) {
        viewModelScope.launch {
            _selectedBranch.value = branchId
            val branchDetail = getBranchDetail(branchId) // Fetch branch details
            val branchProducts = getBranchProducts(branchId) // Fetch products
            _products.value = branchProducts
        }
    }
}
