package com.thewarehouses.thewarehousespecials

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okio.IOException
import org.json.JSONObject

suspend fun getBranchProducts(branchId: String): List<Map<String, Any>> = withContext(Dispatchers.IO) {
    val client = OkHttpClient()

    val request = Request.Builder()
        .url("https://twg.azure-api.net/twl-store/managers-specials?BranchId=$branchId")
        .addHeader("Ocp-Apim-Subscription-Key", "2861c6ce898e4f58a1ad04bd0c3f02a1")
        .build()

    client.newCall(request).execute().use { response ->
        if (!response.isSuccessful) throw IOException("Unexpected code $response")

        val responseData = response.body?.string()
        val json = JSONObject(responseData)
        val products = json.getJSONArray("products")

        List(products.length()) { i ->
            val product = products.getJSONObject(i)
            mapOf(
                "productName" to product.getString("productName"),
                "originalPrice" to product.getJSONObject("priceInfo").getDouble("branchPrice"),
                "discountPrice" to product.getJSONObject("priceInfo").getDouble("price"),
                "imageUrl" to product.getString("imageUrl")
            )
        }
    }
}
