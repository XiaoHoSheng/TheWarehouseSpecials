@file:OptIn(ExperimentalMaterial3Api::class)

package com.thewarehouses.thewarehousespecials

import androidx.compose.runtime.Composable
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest


@Composable
fun MainScreen(
    branchNames: List<String>,
    selectedBranch: String,
    products: List<Map<String, Any>>,
    onBranchSelected: (String) -> Unit,
    onProductClicked: (Map<String, Any>) -> Unit,
    onStoreDetailsClicked: () -> Unit
) {
    Column(
        modifier = Modifier) {

        // 顶部栏
        TopAppBar(
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.logo_thewarehouse),
                        contentDescription = "Logo",
                        modifier = Modifier.size(32.dp)
                    )
                    Text(
                        text = selectedBranch,
                        style = MaterialTheme.typography.titleLarge
                    )
                    IconButton(onClick = { onStoreDetailsClicked() }) {
                        Icon(imageVector = Icons.Default.Info, contentDescription = "Store Details")
                    }
                }
            }
        )

        // 商品列表
        LazyColumn {
            items(products) { product ->
                ProductRow(product, onProductClicked)
            }
        }

        // 底部导航栏

        BottomAppBar(modifier = Modifier .background(color = Color.Blue)) {
            NavigationBarItem(
                icon = { Icon(imageVector = Icons.Default.Home, contentDescription = "Home") },
                selected = true,
                onClick = { /* No-op, already on home screen */ }
            )
            NavigationBarItem(
                icon = { Icon(imageVector = Icons.Default.Favorite, contentDescription = "Favorites") },
                selected = false,
                onClick = { /* No-op, placeholder for future use */ }
            )
        }
    }
}


@Composable
fun DropdownMenu(
    branchNames: List<String>,
    selectedBranch: String,
    onBranchSelected: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    var selectedText by remember { mutableStateOf(selectedBranch) }

    Box() {

        Text(
            text = selectedText,
            modifier = Modifier
                .clickable(onClick = { expanded = true })
                .padding(16.dp)
        )
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            branchNames.forEach { branch ->
                DropdownMenuItem(
                    text = { Text(branch) },
                    onClick = {
                    selectedText = branch
                    expanded = false
                    onBranchSelected(branch)
                })
            }
        }
    }
}

@Composable
fun ProductRow(product: Map<String, Any>, onProductClicked: (Map<String, Any>) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
            .clickable { onProductClicked(product) }
    ) {
        AsyncImage(
            model = ImageRequest.Builder(LocalContext.current)
                .data(product["imageUrl"].toString())
                .build(),
            contentDescription = product["productName"].toString(),
            modifier = Modifier.size(64.dp)
        )

        Column(modifier = Modifier.padding(start = 8.dp)) {
            Text(text = product["productName"].toString())
            Text(text = "Original Price: ${product["originalPrice"]}")
            Text(text = "Discount Price: ${product["discountPrice"]}")
        }
    }
}

