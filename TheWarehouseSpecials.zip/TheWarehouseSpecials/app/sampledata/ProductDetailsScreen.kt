package com.thewarehouses.thewarehousespecials

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest

@Composable
fun ProductDetailsScreen(product: Map<String, Any>) {
    Column(modifier = Modifier.padding(16.dp)) {
        AsyncImage(
            model = ImageRequest.Builder(LocalContext.current)
                .data(product["imageUrl"].toString())
                .build(),
            contentDescription = product["productName"].toString(),
            modifier = Modifier.fillMaxWidth().height(200.dp)
        )
        Text(text = "Product Name: ${product["productName"]}")
        Text(text = "Description: ${product["description"] ?: "No description available"}")
        Text(text = "Original Price: ${product["originalPrice"]}")
        Text(text = "Discount Price: ${product["discountPrice"]}")
    }
}
