package com.thewarehouses.thewarehousespecials
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okio.IOException
import org.json.JSONObject

suspend fun getBranchDetail(branchId: String): JSONObject = withContext(Dispatchers.IO) {
    val client = OkHttpClient()

    val request = Request.Builder()
        .url("https://twg.azure-api.net/twl-store/branches")
        .addHeader("Ocp-Apim-Subscription-Key", "2861c6ce898e4f58a1ad04bd0c3f02a1")
        .build()

    client.newCall(request).execute().use { response ->
        if (!response.isSuccessful) throw IOException("Unexpected code $response")

        val responseData = response.body?.string()
        val json = JSONObject(responseData)
        val branches = json.getJSONArray("branches")

        for (i in 0 until branches.length()) {
            val branch = branches.getJSONObject(i)
            if (branch.getString("branchId") == branchId) {
                return@withContext branch
            }
        }
        throw IllegalArgumentException("Branch with id $branchId not found")
    }
}
