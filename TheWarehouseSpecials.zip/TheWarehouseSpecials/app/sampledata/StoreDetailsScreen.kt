package com.thewarehouses.thewarehousespecials

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import org.json.JSONObject

@Composable
fun StoreDetailsScreen(storeDetails: JSONObject) {
    Column(modifier = Modifier.padding(16.dp)) {
        Text(text = "Store Name: ${storeDetails.getString("name")}")
        Text(text = "Location: ${storeDetails.getJSONObject("address").getString("fullAddress")}")
        Text(text = "Operating Hours:")
        storeDetails.getJSONArray("tradingHours").let { hours ->
            for (i in 0 until hours.length()) {
                val day = hours.getJSONObject(i)
                Text(text = "Day ${day.getInt("dayOfWeek")}: ${day.getString("openingTime")} - ${day.getString("closingTime")}")
            }
        }
        Text(text = "Email: ${storeDetails.getString("email")}")
        Text(text = "Phone: ${storeDetails.getJSONObject("phone").getString("prefix")} ${storeDetails.getJSONObject("phone").getString("number")}")
    }
}
