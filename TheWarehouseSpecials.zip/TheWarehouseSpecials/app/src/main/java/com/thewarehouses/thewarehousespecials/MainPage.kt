package com.thewarehouses.thewarehousespecials

import android.util.Log
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.material3.TopAppBarDefaults.topAppBarColors
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import org.json.JSONObject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun branchSelector(
    selectedBranchId: Int,
    branchInfo: List<Triple<String, Int, String>>,
    onBranchSelected: (Int) -> Unit,
    onInfoClicked: () -> Unit
) {
    // State to track if the dropdown menu is expanded
    var expanded by remember { mutableStateOf(false) }
    // Access to device-specific configurations such as screen dimensions
    val configuration = LocalConfiguration.current
    // Calculate the screen height to use later in UI sizing
    val screenHeight = configuration.screenHeightDp.dp

    // Find the selected branch from the list using the branch ID
    val selectedBranch = branchInfo.find { it.second == selectedBranchId }
    // Set the display name of the selected branch, default to "Select Branch..." if not found
    val selectedBranchName = selectedBranch?.first ?: "Select Branch..."

    // Sort branches first by region (third element of the Triple) and then by branch name (first element of the Triple)
    val groupedBranches = branchInfo
        .sortedWith(compareBy<Triple<String, Int, String>> { it.third }.thenBy { it.first })
        .groupBy { it.third }

    // Remember expanded states for each region, initializing them to true (expanded)
    val expandedRegions = remember(groupedBranches.keys) {
        mutableStateMapOf<String, Boolean>().also { map ->
            groupedBranches.keys.forEach { map[it] = true }
        }
    }

    // Asynchronously fetch today's hours for the selected branch
    val todayHours by produceState(initialValue = "Loading hours...", selectedBranchId) {
        value = getTodayHoursForBranch(selectedBranchId)
    }

    // Main row layout for the selector
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
        // Logo image
        Image(
            painter = painterResource(id = R.drawable.twl___app_icon3x),
            contentDescription = "Logo",
            modifier = Modifier.size(35.dp)
        )
        // Spacer to provide visual separation between the logo and the next UI element
        Spacer(modifier = Modifier.width(8.dp))

        // Box to hold the branch dropdown and its interaction elements
        Box(modifier = Modifier.weight(1f).wrapContentSize(Alignment.Center)) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                // Clickable row for the dropdown, showing the selected branch and an arrow icon
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center, modifier = Modifier.clickable { expanded = true }.padding(8.dp)) {
                    Text(
                        text = selectedBranchName,
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Icon(
                        painter = painterResource(id = R.drawable.ic_arrow_down),
                        contentDescription = "Dropdown",
                        modifier = Modifier.size(16.dp)
                    )
                }
                // Displaying today's hours directly below the dropdown selector
                Text(
                    text = todayHours,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(bottom = 5.dp)
                )

                // Dropdown menu to display branches, with handling for expansion and selection
                DropdownMenu(
                    expanded = expanded,
                    onDismissRequest = { expanded = false },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(screenHeight / 9 * 7) // Height is a fraction of the screen height
                        .background(color = MaterialTheme.colorScheme.surfaceContainerHighest)
                        .padding(horizontal = 10.dp)
                ) {
                    // Iterate over each region and its branches
                    groupedBranches.forEach { (region, branches) ->
                        // Header for each region that can be clicked to expand/collapse the list of branches
                        DropdownMenuSectionHeader(regions = region, onClick = {
                            expandedRegions[region] = !(expandedRegions[region] ?: true)
                        })
                        // Display branches under each region if that region is expanded
                        if (expandedRegions[region] == true) {
                            branches.forEach { (name, id, _) ->
                                DropdownMenuItem(
                                    contentPadding = PaddingValues(0.dp),
                                    onClick = {
                                        expanded = false
                                        onBranchSelected(id)
                                    },
                                    text = { Text(
                                        text = name,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        modifier = Modifier.padding(horizontal = 20.dp))
                                    })
                                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant, thickness = 1.dp)
                            }
                        }
                    }
                }
            }
        }

        // Spacer for alignment
        Spacer(modifier = Modifier.width(8.dp))

        // Information button to provide additional actions or details
        IconButton(onClick = onInfoClicked) {
            Icon(painter = painterResource(id = R.drawable.info), contentDescription = "Store Info", modifier = Modifier.size(25.dp))
        }
    }
}


@Composable
fun DropdownMenuSectionHeader(regions: String, onClick: () -> Unit) {
    Text(
        text = regions,
        style = MaterialTheme.typography.titleMedium,
        color = Color.White,
        fontWeight = FontWeight.Bold,
        modifier = Modifier
            .fillMaxWidth()
            .background(color = Color(0xFFC10001))
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp, horizontal = 10.dp)
    )
}

@Composable
@OptIn(ExperimentalMaterial3Api::class)
fun showMainPage() {
    // States for managing branch ID, detail visibility, and product selections
    var selectedBranchId by rememberSaveable { mutableIntStateOf(103) }
    var showStoreDetail by rememberSaveable { mutableStateOf(false) }
    val branchNames = rememberSaveable { mutableStateOf(emptyList<Triple<String, Int, String>>()) }
    var selectedProductId by rememberSaveable { mutableStateOf<String?>(null) }
    val branchProducts = rememberSaveable { mutableStateOf(emptyList<String>()) }
    var isLoading by rememberSaveable { mutableStateOf(false) }
    var hasError by rememberSaveable { mutableStateOf(false) }
    var errorMessage by rememberSaveable { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val listState = rememberSaveable(saver = LazyListState.Saver) { LazyListState() }

    // Effect to load products when the selected branch ID changes
    LaunchedEffect(selectedBranchId) {
        loadProductsAsync(selectedBranchId, branchProducts, listState, scope, onError = { message ->
            errorMessage = message
            hasError = true
            isLoading = false
        }, onSuccess = {
            isLoading = false
            hasError = false
        })
    }

    // Handle errors by showing an error message and a retry button
    if (hasError) {
        Column(modifier = Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text(text = errorMessage, color = MaterialTheme.colorScheme.error)
            Button(onClick = {
                isLoading = true
                hasError = false
                loadProductsAsync(selectedBranchId, branchProducts, listState, scope, onError = { msg ->
                    errorMessage = msg
                    hasError = true
                    isLoading = false
                }, onSuccess = {
                    isLoading = false
                    hasError = false
                })
            }) {
                Text("Retry")
            }
        }
        return
    }

    // Initial load of branch data
    LaunchedEffect(Unit) {
        if (branchNames.value.isEmpty()) {
            val branches = getBranch() // Fetch data from API
            branchNames.value = branches.map {
                Triple(
                    it.getString("name"),
                    it.getInt("branchId"),
                    getRegionFullName(it.getString("region")) // Convert region code to full name
                )
            }
            if (branchNames.value.isNotEmpty()) {
                selectedBranchId = branchNames.value.first().second
                isLoading = true
                loadProductsAsync(selectedBranchId, branchProducts, listState, scope, onError = { message ->
                    hasError = true
                    errorMessage = message
                }) {
                    isLoading = false
                    hasError = false
                }
            }
        }
    }

    // React to changes in the selected branch ID for product loading
    LaunchedEffect(selectedBranchId) {
        if (branchProducts.value.isEmpty()) {
            isLoading = true
            scope.launch {
                listState.scrollToItem(0)
                loadProductsAsync(selectedBranchId, branchProducts, listState, scope, onError = { message ->
                    hasError = true
                    errorMessage = message
                }) {
                    isLoading = false
                    hasError = false
                }
            }
        }
    }

    // Handle navigation and content display based on the state
    when {
        showStoreDetail -> {
            StoreDetailScreen(branchId = selectedBranchId) {
                showStoreDetail = false
            }
        }
        selectedProductId != null -> {
            val branchName = branchNames.value.find { it.second == selectedBranchId }?.first ?: "Unknown Store"
            ProductDetailScreen(
                branchId = selectedBranchId,
                productId = selectedProductId!!,
                branchProducts = branchProducts.value.map { JSONObject(it) },
                branchName = branchName,
                onBackPressed = {
                    selectedProductId = null
                }
            )
        }
        else -> {
            Scaffold(
                topBar = {
                    TopAppBar(
                        colors = topAppBarColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
                        title = {
                            branchSelector(
                                selectedBranchId,
                                branchNames.value,
                                onBranchSelected = { branchId ->
                                    selectedBranchId = branchId
                                    branchProducts.value = emptyList()
                                    isLoading = true
                                    scope.launch {
                                        listState.scrollToItem(0)
                                        loadProductsAsync(branchId, branchProducts, listState, scope, onError = { message ->
                                            hasError = true
                                            errorMessage = message
                                        }) {
                                            isLoading = false
                                            hasError = false
                                        }
                                    }
                                },
                                onInfoClicked = {
                                    showStoreDetail = true
                                }
                            )
                        }
                    )
                }
            ) { paddingValues ->
                // Handle UI states for loading, error, and list display
                when {
                    isLoading && branchProducts.value.isEmpty() -> {
                        Box(
                            modifier = Modifier
                                .padding(paddingValues)
                                .fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator()
                        }
                    }
                    hasError && branchProducts.value.isEmpty() -> {
                        Column(
                            modifier = Modifier
                                .padding(paddingValues)
                                .fillMaxSize(),
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(text = errorMessage, color = MaterialTheme.colorScheme.error)
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(onClick = {
                                hasError = false
                                isLoading = true
                                loadProductsAsync(selectedBranchId, branchProducts, listState, scope, onError = { message ->
                                    hasError = true
                                    errorMessage = message
                                }) {
                                    isLoading = false
                                    hasError = false
                                }
                            }) {
                                Text(text = "Retry")
                            }
                        }
                    }
                    else -> {
                        LazyColumn(
                            state = listState,
                            modifier = Modifier
                                .padding(paddingValues)
                        ) {
                            items(branchProducts.value) { productJson ->
                                val product = remember { JSONObject(productJson) }
                                ProductItem(
                                    product = product,
                                    onProductSelected = { selectedProductId = it.optString("productId") }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ProductItem(product: JSONObject, onProductSelected: (JSONObject) -> Unit) {
    // Defines a column layout for displaying product information.
    Column(
        modifier = Modifier
            .fillMaxWidth() // Ensures the column takes up the full width available.
            .clickable { onProductSelected(product) } // Adds click functionality to select the product.
            .background(color = MaterialTheme.colorScheme.surface) // Sets the background color from the theme.
    ) {
        // Box to add padding around the product name for better spacing.
        Box(modifier = Modifier.padding(start = 20.dp, end = 20.dp, bottom = 5.dp, top = 5.dp)) {
            // Text element for the product name, styled using MaterialTheme typography.
            Text(
                text = product.optString("productName", "Unknown Product"), // Gets product name or defaults to "Unknown Product".
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface, // Sets text color from the theme.
            )
        }

        // Row layout to display product image and price information side by side.
        Row(
            modifier = Modifier.padding(start = 20.dp, end = 10.dp, bottom = 5.dp)
        ) {
            // Image element for the product, uses a placeholder if the image URL is missing.
            AsyncImage(
                model = product.optString("imageUrl", ""),
                contentDescription = null,
                modifier = Modifier.size(90.dp), // Sets the size of the image.
                error = painterResource(id = R.drawable.no_pic) // Placeholder image used if the actual image fails to load.
            )

            // Column to display price information.
            Column(
                modifier = Modifier
                    .align(Alignment.CenterVertically) // Centers the column vertically within the row.
                    .fillMaxWidth(0.95f) // Takes up most of the width available in the row.
                    .padding(start = 20.dp),
            ) {
                // Conditionally displays price details based on whether the min and max prices are the same.
                if (product.getDouble("minOriginalPrice") == product.getDouble("maxOriginalPrice")) {
                    // Displays single price if min and max are equal.
                    Text(
                        text = "$${product.getDouble("minDiscountPrice")}",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFE52625), // Red color for emphasis on price.
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "$${product.getDouble("minOriginalPrice")}",
                        color = MaterialTheme.colorScheme.onSurface,
                        style = MaterialTheme.typography.bodyMedium.copy(textDecoration = TextDecoration.LineThrough) // Applies strikethrough decoration.
                    )
                } else {
                    // Displays a price range if min and max prices differ.
                    Text(
                        text = "$${product.getDouble("minDiscountPrice")} - $${product.getDouble("maxDiscountPrice")}",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFE52625),
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "$${product.getDouble("minOriginalPrice")} - $${product.getDouble("maxOriginalPrice")}",
                        color = MaterialTheme.colorScheme.onSurface,
                        style = MaterialTheme.typography.bodyMedium.copy(textDecoration = TextDecoration.LineThrough)
                    )
                }
            }

            // Small column to hold an icon indicating more details or navigation.
            Column(
                modifier = Modifier
                    .align(Alignment.CenterVertically) // Aligns the column content vertically center.
                    .width(20.dp) // Fixed width for the icon container.
            ) {
                Icon(
                    painter = painterResource(id = R.drawable.ic_arrow_right),
                    contentDescription = "Arrow", // Descriptive text for screen readers.
                    modifier = Modifier.size(18.dp) // Sets the size of the icon.
                )
            }
        }
    }
    // Divider line to visually separate items in a list.
    HorizontalDivider(
        thickness = 1.dp,
        color = MaterialTheme.colorScheme.outlineVariant, // Color for the divider from the theme.
        modifier = Modifier
            .background(color = MaterialTheme.colorScheme.surface) // Sets the background color to match the column.
            .padding(horizontal = 10.dp) // Adds horizontal padding.
    )
}

// Defines a function to asynchronously load product details for a specific branch.
private fun loadProductsAsync(
    branchId: Int,  // Branch identifier for which products are to be loaded.
    branchProducts: MutableState<List<String>>,  // Mutable state to store the list of product details.
    listState: LazyListState,  // State of the list which might need to be updated after fetching products.
    scope: CoroutineScope,  // Coroutine scope within which network requests are made.
    onError: (String) -> Unit,  // Callback to handle errors.
    onSuccess: () -> Unit = {}  // Callback to execute on successful loading of products.
) {
    // Launch a coroutine within the provided CoroutineScope.
    scope.launch {
        var attempts = 0  // Counter for the number of attempts made.
        val maxAttempts = 5  // Maximum number of attempts allowed to fetch the products.

        // Retry loop that runs until the max number of attempts is reached.
        while (attempts < maxAttempts) {
            try {
                // Attempt to fetch products for the given branch ID.
                val products = getProductByBID(branchId)
                // Check if the fetched products list is empty.
                if (products.isEmpty()) {
                    // If no products are found, invoke the error callback with a message.
                    onError("Sorry, unable to connect to the server.")
                } else {
                    // If products are found, update the state with the list of products converted to strings.
                    branchProducts.value = products.map { it.toString() }
                    // Invoke the success callback function.
                    onSuccess()
                    // Exit the loop and function successfully.
                    return@launch
                }
            } catch (e: Exception) {
                // Log the error along with the attempt count and error message.
                Log.e("loadProducts", "Attempt $attempts: Error loading products: ${e.message}")
            }
            // Increment the attempt count.
            attempts++
            // Wait for 2 seconds before making another attempt.
            delay(2000)
        }
        // If all attempts fail, invoke the error callback with a message suggesting the user to retry after ensuring network connectivity.
        onError("Failed to load products after $maxAttempts attempts.\nPlease click Retry after connecting to the network")
    }
}




