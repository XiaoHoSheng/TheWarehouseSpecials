package com.thewarehouses.thewarehousespecials

import android.graphics.Bitmap
import android.util.Log
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter
import com.google.zxing.common.BitMatrix
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okio.IOException
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Locale

/**
 * Merges or updates product information in a map, ensuring that each product is uniquely identified
 * and all relevant data is accurately consolidated.
 *
 * @param product The JSONObject containing current product data to be processed.
 * @param uniqueProducts A MutableMap that stores unique products keyed by a unique identifier (productId or productName).
 * @param parentProduct The optional JSONObject of a parent product, which might contribute additional or overriding data.
 */
private fun mergeProductInfo(
    product: JSONObject,
    uniqueProducts: MutableMap<String, JSONObject>,
    parentProduct: JSONObject?
) {
    // Extract a unique identifier for the product. Prefer the parent's productName, falling back to product's productId.
    val parentId = parentProduct?.optString("productName", "") ?: product.optString("productId", "")

    // If the identifier is empty, log an error and exit the function.
    if (parentId.isEmpty()) {
        Log.e("ProductProcessing", "Product is missing a productId or productName. JSON: $product")
        return
    }

    // Retrieve or create a new product JSON object in the uniqueProducts map using the unique identifier.
    val currentProduct = uniqueProducts.getOrPut(parentId) {
        JSONObject().apply {
            // Initialize the product entry with default or fallback values from the parent or current product.
            put("productId", parentId)
            put("productName", parentProduct?.optString("productName") ?: product.optString("productName", "Unknown Product"))
            put("imageUrl", parentProduct?.optString("imageUrl") ?: product.optString("imageUrl", ""))
            put("minOriginalPrice", Double.MAX_VALUE)
            put("maxOriginalPrice", Double.MIN_VALUE)
            put("minDiscountPrice", Double.MAX_VALUE)
            put("maxDiscountPrice", Double.MIN_VALUE)
            put("endDateTime", parentProduct?.optString("endDateTime") ?: product.optString("endDateTime", "N/A"))
            put("barcode", product.optString("barcode", parentProduct?.optString("barcode") ?: "Unknown"))
            put("soh", product.optString("soh"))
            // If parent product contains sizes, inherit this information.
            if (parentProduct?.has("sizes") == true) {
                put("sizes", parentProduct.getJSONArray("sizes"))
            }
        }
    }

    // Extract price information from the product, handling potential absence of data.
    val priceInfo = product.optJSONObject("priceInfo")
    val originalPrice = priceInfo?.optDouble("branchPrice", 0.0) ?: 0.0
    val discountPrice = priceInfo?.optDouble("price", 0.0) ?: 0.0

    // Update the product's price range information with new data.
    currentProduct.put("minOriginalPrice", kotlin.math.min(currentProduct.getDouble("minOriginalPrice"), originalPrice))
    currentProduct.put("maxOriginalPrice", kotlin.math.max(currentProduct.getDouble("maxOriginalPrice"), originalPrice))
    currentProduct.put("minDiscountPrice", kotlin.math.min(currentProduct.getDouble("minDiscountPrice"), discountPrice))
    currentProduct.put("maxDiscountPrice", kotlin.math.max(currentProduct.getDouble("maxDiscountPrice"), discountPrice))

    // Update image URL if the current product lacks one and the new data includes it.
    if (currentProduct.optString("imageUrl").isEmpty() && product.has("imageUrl")) {
        currentProduct.put("imageUrl", product.getString("imageUrl"))
    }
    // Update the end date/time if the current record is empty and the new data includes it.
    if (currentProduct.optString("endDateTime").isEmpty() && product.has("endDateTime")) {
        currentProduct.put("endDateTime", product.getString("endDateTime"))
    }

    // Ensure that the barcode from either the current product or the parent product is retained correctly.
    if (currentProduct.optString("barcode") == "Unknown" && (product.has("barcode") || parentProduct?.has("barcode") == true)) {
        currentProduct.put("barcode", product.optString("barcode", parentProduct?.optString("barcode") ?: "Unknown"))
    }
}

/**
 * Fetches product information by branch ID with caching and retries upon failure.
 *
 * @param branchId The unique identifier for the branch to fetch products from.
 * @return A list of JSONObjects representing the products of the specified branch.
 */
private val productCache = mutableMapOf<Int, List<JSONObject>>()
suspend fun getProductByBID(branchId: Int): List<JSONObject> = withContext(Dispatchers.IO) {
    // First, check if the products for this branch are already cached.
    productCache[branchId]?.let {
        // If available in cache, return the cached list immediately.
        return@withContext it
    }

    // If not in cache, initialize retry counter.
    var retryCount = 0
    // Attempt to fetch data up to three times.
    while (retryCount < 3) {
        try {
            // Create an OkHttpClient instance.
            val client = OkHttpClient()
            // Prepare the request with URL and headers.
            val request = Request.Builder()
                .url("https://twg.azure-api.net/twl-store/managers-specials?BranchId=$branchId")
//                .addHeader("Ocp-Apim-Subscription-Key", "2861c6ce898e4f58a1ad04bd0c3f02a1")
                .addHeader("Ocp-Apim-Subscription-Key", "bdd6dd4ee38e40ec970923e318cc35d0")
                .build()

            // Execute the request.
            client.newCall(request).execute().use { response ->
                // Check if the response is successful.
                if (!response.isSuccessful) throw IOException("Unexpected code $response")

                // Parse the response body to JSON.
                val responseData = response.body?.string()
                val json = responseData?.let { JSONObject(it) }
                val products = json?.getJSONArray("products") ?: JSONArray()
                val uniqueProducts = mutableMapOf<String, JSONObject>()

                // Process each product in the response.
                for (i in 0 until products.length()) {
                    val product = products.getJSONObject(i)
                    // If product has variants (sizes), merge each variant.
                    if (product.has("sizes")) {
                        val sizes = product.getJSONArray("sizes")
                        for (j in 0 until sizes.length()) {
                            val variant = sizes.getJSONObject(j)
                            mergeProductInfo(variant, uniqueProducts, product)
                        }
                    } else {
                        // Otherwise, merge the product as is.
                        mergeProductInfo(product, uniqueProducts, null)
                    }
                }
                // Convert the map of unique products to a list.
                val result = uniqueProducts.values.toList()
                // Cache the result for this branch ID.
                productCache[branchId] = result
                // Return the result and exit the function.
                return@withContext result
            }
        } catch (e: IOException) {
            // Log the retry attempt and error.
            retryCount++
            Log.e("getProductByBID", "Retry $retryCount failed: ${e.message}")
            // If retries exceed 3, return an empty list.
            if (retryCount >= 3) {
                return@withContext emptyList()
            }
        }
    }
    // Return an empty list if all retries failed.
    emptyList()
}

/**
 * Retrieves detailed information about a specific product identified by its ID.
 * If the product is not found after several retries, it returns a map indicating an error.
 *
 * @param branchId The branch identifier where the product is listed.
 * @param productId The unique product identifier to search for.
 * @param branchProducts A list of products available at the branch, each represented as a JSONObject.
 * @return A map containing detailed product information or an error message.
 */
fun getPDetailByBnPID(branchId: Int, productId: String, branchProducts: List<JSONObject>): Map<String, Any?> {
    var retryCount = 0  // Counter to keep track of the number of retries.

    // Attempt to find and process the product up to 3 times in case of errors.
    while (retryCount < 3) {
        try {
            // Search for the product by productId in the list of branch products.
            val product = branchProducts.find { it.optString("productId") == productId }

            // If the product is found, extract and return its details.
            if (product != null) {
                // Extract various attributes of the product.
                val productName = product.optString("productName", "Unknown Product")
                val barcode = product.optString("barcode", "Unknown")
                val imageUrl = product.optString("imageUrl")
                val endDateTime = product.optString("endDateTime", "N/A")
                val originalPrice = product.optDouble("minOriginalPrice", 0.0)
                val discountPrice = product.optDouble("minDiscountPrice", 0.0)
                val sizes = product.optJSONArray("sizes")
                val soh = product.optString("soh", "0")

                // Determine the product type based on the availability and count of sizes.
                val productType = when {
                    sizes == null || sizes.length() == 0 -> "independent"
                    sizes.length() == 1 -> "semi-independent"
                    sizes.length() > 1 -> "composite"
                    else -> "unknown"
                }

                // Return a map of the product details.
                return mapOf(
                    "productName" to productName,
                    "imageUrl" to imageUrl,
                    "originalPrice" to originalPrice,
                    "discountPrice" to discountPrice,
                    "branchId" to branchId,
                    "endDateTime" to endDateTime,
                    "productType" to productType,
                    "sizes" to sizes,
                    "barcode" to barcode,
                    "soh" to soh,
                )
            } else {
                // If no product matches the ID, return an empty map.
                return emptyMap()
            }
        } catch (e: Exception) {
            // If an exception occurs, log the error and increment the retry counter.
            retryCount++
            Log.e("getPDetailByBnPID", "Retry $retryCount failed: ${e.message}")
            // If three retries have failed, return a map indicating a network error.
            if (retryCount >= 3) {
                return mapOf("error" to "Network error")
            }
        }
    }
    // Return a map indicating a network error if all retries fail.
    return mapOf("error" to "Network error")
}


// Function to generate barcode using ZXing
fun generateBarcode(data: String,barcodeColor: Int): Bitmap? {
    return try {
        val bitMatrix: BitMatrix = MultiFormatWriter().encode(data, BarcodeFormat.CODE_128, 900, 200)
        val width = bitMatrix.width
        val height = bitMatrix.height
        val pixels = IntArray(width * height)
        for (y in 0 until height) {
            for (x in 0 until width) {
                pixels[y * width + x] = if (bitMatrix[x, y]) barcodeColor else android.graphics.Color.TRANSPARENT
            }
        }
        Bitmap.createBitmap(pixels, width, height, Bitmap.Config.ARGB_8888)
    } catch (e: Exception) {
        Log.e("BarcodeError", "Error generating barcode: ${e.message}")
        null
    }
}

fun formatDateString(inputDate: String): String {
    val inputFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.getDefault())
    val outputFormat = SimpleDateFormat("yyyy/MM/dd", Locale.getDefault())

    return try {
        val parsedDate = inputFormat.parse(inputDate)
        outputFormat.format(parsedDate)
    } catch (e: Exception) {
        e.printStackTrace()
        "Invalid date"
    }
}
