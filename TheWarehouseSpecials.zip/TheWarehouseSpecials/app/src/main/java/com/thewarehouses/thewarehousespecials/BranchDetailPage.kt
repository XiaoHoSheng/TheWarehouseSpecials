package com.thewarehouses.thewarehousespecials

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import org.json.JSONObject
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StoreDetailScreen(branchId: Int, onBack: () -> Unit) {
    // State to hold store details, initialized as null and updated asynchronously
    val storeDetail = remember { mutableStateOf<JSONObject?>(null) }

    // Launches a coroutine when branchId changes, fetching branch details asynchronously
    LaunchedEffect(branchId) {
        storeDetail.value = getBranchDetailByBID(branchId)
    }

    // Handles the Android back button press to execute the provided onBack function
    BackHandler(onBack = onBack)

    // Scaffold structure provides a material design layout with a top app bar
    Scaffold(
        topBar = {
            // Top app bar with a title and a back navigation icon
            TopAppBar(
                title = { Text("Branch Details") },
                navigationIcon = {
                    // IconButton used for navigation back, with an arrow back icon
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                }
            )
        }
    ) { paddingValues ->
        // Displays branch details if available, otherwise shows a loading spinner
        storeDetail.value?.let { detail ->
            // Layout for displaying store details
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(horizontal = 16.dp, vertical = 24.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Displays the name of the branch in headline style
                Text(text = "Branch of ${detail.getString("name")}", style = MaterialTheme.typography.headlineMedium)

                // Displays the branch ID
                Text(text = "Branch ID: ${detail.getString("branchId")}", style = MaterialTheme.typography.bodyLarge)

                // Optionally displays a description, or "N/A" if not available
                Text(text = "Description: ${detail.optString("description", "N/A")}", style = MaterialTheme.typography.bodyMedium)

                Spacer(modifier = Modifier.padding(vertical = 8.dp))

                // Section header for contact information
                Text(text = "Contact Information", style = MaterialTheme.typography.headlineSmall)

                // Displays the full address of the branch
                Text(
                    text = "Address: ${detail.getJSONObject("address").getString("fullAddress")}",
                    style = MaterialTheme.typography.bodyMedium
                )
                // Displays the phone number, formatted
                Text(
                    text = "Phone: ${detail.getJSONObject("phone").getString("prefix")}-${detail.getJSONObject("phone").getString("number")}",
                    style = MaterialTheme.typography.bodyMedium
                )
                // Displays the email address
                Text(text = "Email: ${detail.getString("email")}", style = MaterialTheme.typography.bodyMedium)

                Spacer(modifier = Modifier.padding(vertical = 8.dp))

                // Section header for trading hours
                Text(text = "Trading Hours", style = MaterialTheme.typography.headlineSmall)

                // Iterates over trading hours array and displays each day's hours
                val tradingHours = detail.getJSONArray("tradingHours")
                for (i in 0 until tradingHours.length()) {
                    val day = tradingHours.getJSONObject(i)
                    Text(
                        text = "${getDayOfWeek(day.getInt("dayOfWeek"))}: ${day.getString("openingTime")} - ${day.getString("closingTime")}",
                        style = MaterialTheme.typography.bodyLarge
                    )
                }
            }
        } ?: run {
            // Displays a loading spinner while waiting for data
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        }
    }
}

// Converts numerical day of the week to string name
fun getDayOfWeek(dayOfWeek: Int): String {
    return when (dayOfWeek) {
        1 -> "Sunday"
        2 -> "Monday"
        3 -> "Tuesday"
        4 -> "Wednesday"
        5 -> "Thursday"
        6 -> "Friday"
        7 -> "Saturday"
        else -> "Unknown"
    }
}

