package com.thewarehouses.thewarehousespecials

import android.util.Log
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.material3.TopAppBarDefaults.topAppBarColors
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import org.json.JSONArray
import org.json.JSONObject

@Composable
@OptIn(ExperimentalMaterial3Api::class)
fun ProductDetailScreen(
    branchId: Int,
    productId: String,
    branchProducts: List<JSONObject>,
    branchName: String,
    onBackPressed: () -> Unit
) {
    // Handle the hardware back button on Android
    BackHandler(onBack = onBackPressed)

    // State for managing product details, initially fetched using a function that might include retry logic
    var productDetails by remember { mutableStateOf(getPDetailByBnPID(branchId, productId, branchProducts)) }
    var showLargeImage by remember { mutableStateOf(false)}

    // Display a message if no product details are found
    if (productDetails.isEmpty()) {
        Text("Product not found")
        return  // Early return to stop further rendering if the product is not found
    }

    // Extracting details from the productDetails map
    val productType = productDetails["productType"] as? String ?: "independent"
    val sizes = productDetails["sizes"] as? JSONArray
    var selectedVariantIndex by remember { mutableIntStateOf(0) }

    Scaffold(
        topBar = {
                TopAppBar(
                    colors = topAppBarColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
                    title = { Text(text = "$branchName Special") },
                    navigationIcon = {
                        IconButton(onClick = onBackPressed) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                        }
                    },
                )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())  // Allows vertical scrolling
                .background(color = MaterialTheme.colorScheme.surface)
                .padding(16.dp)
        ) {
            AsyncImage(
                model = productDetails["imageUrl"] as? String ?: "",
                contentDescription = null,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(400.dp)
                    .padding(bottom = 10.dp)
                    .clickable { showLargeImage = true },   // Makes the image clickable to show a larger version
                contentScale = ContentScale.Crop
            )
            // Divider for aesthetic separation
            HorizontalDivider(
                thickness = 1.dp,
                color = MaterialTheme.colorScheme.outlineVariant,
                modifier = Modifier .background(color = MaterialTheme.colorScheme.surface))

            // Dialog for showing a large image with zoom and pan capabilities
            if (showLargeImage) {
                Dialog(
                    onDismissRequest = { showLargeImage = false },
                    properties = DialogProperties(
                        usePlatformDefaultWidth = false  // This makes the dialog fullscreen
                    )
                ) {
                    // State for zoom and pan
                    var scale by remember { mutableStateOf(1f) }
                    var offset by remember { mutableStateOf(Offset(0f, 0f)) }

                    val state = rememberTransformableState { zoomChange, offsetChange, _ ->
                        scale *= zoomChange
                        offset += offsetChange
                    }

                    val interactionSource = remember { MutableInteractionSource() }

                    // Fullscreen transparent background Box
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.5f))  // Semi-transparent black background
                            .clickable(
                                indication = null,  // No visual indication when the box is clicked
                                interactionSource = interactionSource  // Use custom interaction source to manage state
                            ) { showLargeImage = false }
                            .padding(15.dp)  // Ensures the image is not edge-to-edge
                            .transformable(state = state)
                            .graphicsLayer(
                                scaleX = maxOf(1f, scale),
                                scaleY = maxOf(1f, scale),
                                translationX = offset.x,
                                translationY = offset.y
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        AsyncImage(
                            model = productDetails["imageUrl"] as? String ?: "",
                            contentDescription = null,
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.matchParentSize()
                        )
                    }
                }
            }

            // Displaying productName
            Text(
                text = productDetails["productName"] as? String ?: "Unknown Product",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.padding(top = 5.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))
            val endDateTime = productDetails["endDateTime"] as String
            val formattedEndDate = formatDateString(endDateTime)
            val discountPrice = productDetails["discountPrice"] as Double
            val originalPrice = productDetails["originalPrice"] as Double
            val saved = (originalPrice-discountPrice)

            // Price and Discount Price
            Row(modifier = Modifier .fillMaxWidth()) {
                Text(
                    modifier = Modifier.padding(start = 1.dp),
                    text = "$${"%.2f".format(discountPrice)}",
                    style = MaterialTheme.typography.headlineLarge,
                    fontSize = 48.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFE52625),
                )

                Spacer(modifier = Modifier.width(10.dp))

                Column(modifier = Modifier .align(Alignment.CenterVertically)) {
                    Text(
                        text = "$${"%.2f".format(originalPrice)}",
                        color = MaterialTheme.colorScheme.onSurface,
                        style = MaterialTheme.typography.labelMedium,
                        textDecoration = TextDecoration.LineThrough,
                    )
                    Text(
                        text = "Save: $${"%.2f".format(saved)}",
                        color = MaterialTheme.colorScheme.onSurface,
                        style = MaterialTheme.typography.labelSmall)
                    Text(
                        text = "Offer ends: $formattedEndDate",
                        color = MaterialTheme.colorScheme.onSurface,
                        style = MaterialTheme.typography.labelSmall)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // If the product is composite, display buttons for selecting sizes/colors
            if (productType == "composite" && sizes != null && sizes.length() > 0) {
                Box(modifier = Modifier
                    .fillMaxWidth(1f)
                ){
                    Text(
                        text = "Size",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface,)
                }
                Row(modifier = Modifier.fillMaxWidth()) {
                    for (i in 0 until sizes.length()) {
                        val variant = sizes.getJSONObject(i)
                        Button(
                            shape = RoundedCornerShape(5.dp),
                            onClick = {
                                selectedVariantIndex = i
                                // Update product details to reflect the selected variant
                                productDetails = productDetails.toMutableMap().apply {
                                    put("productName", variant.optString("productName", productDetails["productName"] as String))
                                    put("imageUrl", variant.optString("imageUrl", productDetails["imageUrl"] as String))
                                    put("originalPrice", variant.optJSONObject("priceInfo")?.optDouble("branchPrice", 0.0) ?: 0.0)
                                    put("discountPrice", variant.optJSONObject("priceInfo")?.optDouble("price", 0.0) ?: 0.0)
                                    put("endDateTime", variant.optString("endDateTime", productDetails["endDateTime"] as String))
                                    put("barcode", variant.optString("barcode", productDetails["barcode"] as String))
                                    put("soh", variant.optString("soh", productDetails["soh"] as String))
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (selectedVariantIndex == i) Color(0xFFE52625) else Color(MaterialTheme.colorScheme.surfaceContainer.value)
                            ),
                            border = BorderStroke(1.dp,Color(MaterialTheme.colorScheme.inverseSurface.value)),
                        ) {
                            Text(
                                text = variant.optJSONObject("size")?.optString("attribute") ?: "N/A",
                                style = MaterialTheme.typography.labelMedium,
                                color = if (selectedVariantIndex == i) Color.White else Color(0xFFE52625)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
            }

            // Generate and display barcode
            val barcode = productDetails["barcode"] as? String ?: "Unknown Barcode"
            Log.e("barcode",barcode)
            val barCodeColor = MaterialTheme.colorScheme.onSurface.toArgb()
            val barcodeBitmap = generateBarcode(barcode,barCodeColor)

            Box(modifier = Modifier
                .fillMaxWidth(1f)
                .padding(bottom = 5.dp)
            ){
                Text(
                    text = "Barcode",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,)
            }
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(100.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    barcodeBitmap?.let {
                        Image(
                            bitmap = it.asImageBitmap(),
                            contentDescription = "Barcode",
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = barcode,
                        style = MaterialTheme.typography.bodyMedium,
                        textAlign = TextAlign.Center
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            val soh = productDetails["soh"]
            Text(
                text = "Stock Level",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface,)
            Text(
                text = "Only $soh units left",
                style = MaterialTheme.typography.bodyLarge,
                color = Color(0xFFE52625))

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "Did you find it?",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface,)

            // Buttons for Yes and No
            Row(
                modifier = Modifier
                    .fillMaxWidth()
            ) {
                Button(
                    shape = RoundedCornerShape(5.dp),
                    onClick = {},
                    colors = ButtonDefaults.buttonColors(Color(MaterialTheme.colorScheme.surfaceContainer.value)),
                    border = BorderStroke(1.dp, Color(MaterialTheme.colorScheme.inverseSurface.value))
                ) {
                    Text(
                        text = "Yes", style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Button(
                    shape = RoundedCornerShape(5.dp),
                    onClick = {},
                    colors = ButtonDefaults.buttonColors(Color(MaterialTheme.colorScheme.surfaceContainer.value)),
                    border = BorderStroke(1.dp, Color(MaterialTheme.colorScheme.inverseSurface.value))
                ) {
                    Text(
                        text = "No", style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

