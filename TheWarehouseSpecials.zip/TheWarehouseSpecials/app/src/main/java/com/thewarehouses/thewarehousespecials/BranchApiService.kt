package com.thewarehouses.thewarehousespecials

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okio.IOException
import org.json.JSONObject
import java.util.Calendar

// Fetch a list of branches from the server asynchronously.
suspend fun getBranch(): List<JSONObject> = withContext(Dispatchers.IO) {
    try {
        // Initialize HTTP client
        val client = OkHttpClient()
        // Prepare the request with URL and headers
        val request = Request.Builder()
            .url("https://twg.azure-api.net/twl-store/branches")
//            .addHeader("Ocp-Apim-Subscription-Key", "2861c6ce898e4f58a1ad04bd0c3f02a1")
            .addHeader("Ocp-Apim-Subscription-Key", "bdd6dd4ee38e40ec970923e318cc35d0")
            .build()

        // Execute the HTTP request
        client.newCall(request).execute().use { response ->
            // Throw an exception if the response is not successful
            if (!response.isSuccessful) throw IOException("Unexpected code $response")

            // Parse the response data into JSON
            val responseData = response.body?.string()
            val json = JSONObject(responseData)
            val branches = json.getJSONArray("branches")

            // Convert JSON array to a List of JSONObjects
            List(branches.length()) { i -> branches.getJSONObject(i) }
        }
    } catch (e: Exception) {
        // Return an empty list if there is any exception
        emptyList<JSONObject>()
    }
}

// Retrieve the details of a specific branch by its ID.
suspend fun getBranchDetailByBID(branchId: Int): JSONObject? {
    // Fetch all branches
    val branches = getBranch()
    // Return the branch details matching the given ID
    return branches.find { it.getInt("branchId") == branchId }
}

// Get the trading hours for a branch by its ID for today.
suspend fun getTodayHoursForBranch(branchId: Int): String = withContext(Dispatchers.IO) {
    // Fetch details for a specific branch
    val branchDetails = getBranchDetailByBID(branchId)

    // Return an error message if branch details are not found
    if (branchDetails == null) {
        return@withContext "Store hours unavailable"
    }

    // Attempt to get trading hours from the branch details
    val tradingHours = branchDetails.optJSONArray("tradingHours") ?: return@withContext "Store hours unavailable"

    // Determine today's day of the week
    val dayOfWeek = Calendar.getInstance().get(Calendar.DAY_OF_WEEK)
    // Extract today's opening hours
    val todayHours = (0 until tradingHours.length()).mapNotNull { index ->
        val dayInfo = tradingHours.optJSONObject(index)
        if (dayInfo != null && dayInfo.optInt("dayOfWeek") == dayOfWeek) {
            val openingTime = dayInfo.optString("openingTime")
            val closingTime = dayInfo.optString("closingTime")
            "Open today $openingTime - $closingTime"
        } else {
            null
        }
    }.firstOrNull()

    // Return today's hours or a default message if not available
    return@withContext todayHours ?: "Store hours unavailable"
}

// Convert a region's short name to its full descriptive name.
fun getRegionFullName(shortName: String): String {
    // Map of short names to full names
    val regionMap = mapOf(
        "NZ-AUK" to "Auckland Region",
        "NZ-BOP" to "Bay of Plenty Region",
        "NZ-MBH" to "Blenheim Region",
        "NZ-CAN" to "Canterbury Region",
        "NZ-GIS" to "Gisborne Region",
        "NZ-HKB" to "Hawkes Bay Region",
        "NZ-MWT" to "Manawatu-Whanganui Region",
        "NZ-NTL" to "Northland Region",
        "NZ-OTA" to "Otago Region",
        "NZ-STL" to "Southland Region",
        "NZ-TKI" to "Taranaki Region",
        "NZ-TAS" to "Tasman Region",
        "NZ-WKO" to "Waikato Region",
        "NZ-WGN" to "Wellington Region",
        "NZ-WTC" to "West Coast Region"
    )
    // Return the full name or "Unknown Region" if not found
    return regionMap[shortName] ?: "Unknown Region"
}

